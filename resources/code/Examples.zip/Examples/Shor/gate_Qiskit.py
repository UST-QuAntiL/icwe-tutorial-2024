#!/usr/bin/env python
# coding: utf-8

# Importar la función shor_circuit de shor_Circuit.py
from shor_Circuit import shor_circuit

# import libraries
import numpy as np
import math
import matplotlib.pyplot as plt
from math import pi
from fractions import Fraction
from math import gcd
import time

# Importar las bibliotecas de Qiskit
from qiskit import QuantumCircuit, transpile
from qiskit.providers.basic_provider import BasicProvider
from qiskit_ibm_provider import IBMProvider
from qiskit.visualization import plot_histogram
from qiskit.circuit.library import QFT, CU1Gate

# Definir la función QFT de Qiskit
def qft_(circuit, qubits):
    n = len(qubits)
    circuit_qft = QFT(num_qubits=n, approximation_degree=0, do_swaps=True, inverse=False, insert_barriers=False, name='qft')
    circuit.compose(circuit_qft, inplace=True)

# Definir una función para crear el circuito
def create_cir():
    shor = shor_circuit()
    qft_(shor, range(4))
    shor.measure(range(4), range(4))
    return shor


def factor(counts):
    N = 15
    a = 7
    
    # Initialize variables to store the numerator and denominator
    numerator = 0
    denominator = 0
    
    for outcome, count in counts.items():
        # Convert the binary outcome to an integer
        outcome_int = int(outcome, 2)
        
        # Compute the phase as the fraction (outcome_int / 2^4)
        phase_frac = Fraction(outcome_int, 2**4)
        
        # Find the denominator of the fraction and its multiplicity
        frac_denominator = phase_frac.denominator
        multiplicity = count
        
        # Accumulate the numerator and denominator products
        numerator += multiplicity * frac_denominator * (a**(frac_denominator // 2) - 1)
        denominator += multiplicity * frac_denominator
        
    # Use the numerator and denominator to compute the factors
    factor1 = gcd(numerator, N)
    factor2 = N // factor1
    
    return factor1, factor2



# Execute circuit
def run(machine, shots):
    circuit = create_cir()
    if machine == "local":
        backend = BasicProvider().get_backend("basic_simulator")
        x = int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        print(counts)
        x, y = factor(counts)
        return [x, y]
    else:
        provider = IBMProvider()
        backend = provider.get_backend(machine)
        x = int(shots)
        job = backend.run(circuit, backend, shots=x)
        result = job.result()
        counts = result.get_counts()
        x, y = factor(counts)
        return [x, y]
