from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit
from numpy import pi

def shor_circuit():
    qreg_q = QuantumRegister(8, 'q')
    creg_c = ClassicalRegister(4, 'c')
    shor = QuantumCircuit(qreg_q, creg_c)  # Use 8 qubits and 4 classical bits

    shor.h(range(4))
    shor.x(4)
    shor.cx(0, 5)
    shor.cx(0, 6)
    shor.cx(1, 4)
    shor.cx(1, 6)
    for i in range(4, 8):
        shor.ccx(0, 1, i)
        

    return shor