from flask import Flask, request, jsonify

# Importar la función run de gate_Qiskit.py
from gate_Qiskit import run

# Definir los nombres de las máquinas
gate_machines_arn = {"local":"local", "ibm_brisbane":"ibm_brisbane", "ibm_osaka":"ibm_osaka", "ibm_kyoto":"ibm_kyoto", "simulator_stabilizer":"simulator_stabilizer", "simulator_mps":"simulator_mps", "simulator_extended_stabilizer":"simulator_extended_stabilizer", "simulator_statevector":"simulator_statevector"}


app = Flask(__name__)

@app.route('/execute', methods=["GET"])
def execute_quantum_task():
    machine = request.args.get('device')
    shots = request.args.get('shots')

    if machine not in gate_machines_arn:
        return "Machine not found", 400

    # Llamar a la función run de gate_Qiskit.py
    response = run(machine, shots)

    json_response = {
        "factors": response
    }
    return jsonify(json_response)

if __name__ == '__main__':
    app.run(host="localhost", port=33888)
