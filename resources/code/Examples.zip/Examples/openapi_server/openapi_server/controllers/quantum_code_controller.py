import connexion
import six
import time
import os

from openapi_server.models.parameters import Parameters  # noqa: E501
from openapi_server.models.parameters_qasm import ParametersQASM  # noqa: E501
from openapi_server import util

def executeAWS(s3_folder, machine, circuit, shots):
    os.environ['AWS_DEFAULT_REGION'] = 'us-west-2'
    if machine=="local":
        device = LocalSimulator()
        result = device.run(circuit, int(shots)).result()
        counts = result.measurement_counts
        return counts
        
    device = AwsDevice(machine)

    if "sv1" not in machine and "tn1" not in machine:
        task = device.run(circuit, s3_folder, int(shots), poll_timeout_seconds=5 * 24 * 60 * 60)
        counts = recover_task_result(task).measurement_counts
        return counts
    else:
        task = device.run(circuit, s3_folder, int(shots))
        counts = task.result().measurement_counts
        return counts

def recover_task_result(task_load):
    # recover task
    sleep_times = 0
    while sleep_times < 100000:
        status = task_load.state()
        print('Status of (reconstructed) task:', status)
        print('\n')
        # wait for job to complete
        # terminal_states = ['COMPLETED', 'FAILED', 'CANCELLED']
        if status == 'COMPLETED':
            # get results
            return task_load.result()
        else:
            time.sleep(1)
            sleep_times = sleep_times + 1
    print("Quantum execution time exceded")
    return None

    



from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, transpile
from qiskit.providers.basic_provider import BasicProvider
from qiskit_ibm_provider import IBMProvider
from numpy import pi


def bernstein_vazirani_ib_mqiskit(machine, shots):  # noqa: E501
    
    """Get the circuit Implementation of Bernstein-Vazirani Algorithm

     # noqa: E501

    :param machine: quantum machine
    :type machine: str
    :param shots: Number of shots
    :type shots: 

    :rtype: None
    """


        
    qr = QuantumRegister(3, 'q')
    anc = QuantumRegister(1, 'ancilla')
    cr = ClassicalRegister(3, 'c')
    qc = QuantumCircuit(qr, anc, cr)
    gate_machines_arn= {"local":"local", "ibm_brisbane":"ibm_brisbane", "ibm_osaka":"ibm_osaka", "ibm_kyoto":"ibm_kyoto", "simulator_stabilizer":"simulator_stabilizer", "simulator_mps":"simulator_mps", "simulator_extended_stabilizer":"simulator_extended_stabilizer", "simulator_statevector":"simulator_statevector"}
    
    qc.x(anc[0])
    qc.h(anc[0])
    qc.h(qr[0])
    qc.h(qr[1])
    qc.h(qr[2])
    qc.cx(qr[0], anc[0])
    qc.cx(qr[1], anc[0])
    qc.cx(qr[2], anc[0])
    qc.h(qr[0])
    qc.h(qr[1])
    qc.h(qr[2])
    qc.barrier(qr)
    qc.measure(qr, cr)
    
    if machine == "local":
        backend = BasicProvider().get_backend("basic_simulator")
        x = int(shots)
        transpiled_circuit = transpile(qc, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts
    else:
        provider = IBMProvider()
        backend = provider.get_backend(gate_machines_arn[machine])
        x = int(shots)
        transpiled_circuit = transpile(qc, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts




from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, transpile
from numpy import pi
from qiskit.providers.basic_provider import BasicProvider
from qiskit_ibm_provider import IBMProvider
import qiskit.qasm3


def bernstein_vazirani_ib_mquirk(machine, shots):  # noqa: E501
    
    """Get the circuit implementation of Bernstein-Vazirani Algorithm

     # noqa: E501

    :param machine: quantum machine
    :type machine: str
    :param shots: Number of shots
    :type shots: 

    :rtype: None
    """


    qreg_q = QuantumRegister(4, 'q')
    creg_c = ClassicalRegister(4, 'c')
    circuit = QuantumCircuit(qreg_q, creg_c)
    gate_machines_arn= {"local":"local", "ibm_brisbane":"ibm_brisbane", "ibm_osaka":"ibm_osaka", "ibm_kyoto":"ibm_kyoto", "simulator_stabilizer":"simulator_stabilizer", "simulator_mps":"simulator_mps", "simulator_extended_stabilizer":"simulator_extended_stabilizer", "simulator_statevector":"simulator_statevector"}
    circuit.h(qreg_q[0])
    circuit.h(qreg_q[1])
    circuit.h(qreg_q[2])
    circuit.x(qreg_q[3])
    circuit.h(qreg_q[3])
    circuit.cx(qreg_q[3], qreg_q[0])
    circuit.cx(qreg_q[3], qreg_q[1])
    circuit.cx(qreg_q[3], qreg_q[2])
    circuit.h(qreg_q[0])
    circuit.h(qreg_q[1])
    circuit.h(qreg_q[2])
    circuit.measure(qreg_q[0], creg_c[0])
    circuit.measure(qreg_q[1], creg_c[1])
    circuit.measure(qreg_q[2], creg_c[2])
    if machine == "local":
        backend = BasicProvider().get_backend("basic_simulator")
        x=int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts
    else:
        provider = IBMProvider()
        backend = provider.get_backend(gate_machines_arn[machine])
        x=int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, backend, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts




from braket.circuits import Gate
from braket.circuits import Circuit
from braket.devices import LocalSimulator
from braket.aws import AwsDevice


def circuit_aws_parameterized(machine, shots, parameters=None):  # noqa: E501
    
    """Get the circuit implementation of circuit with parameters

     # noqa: E501

    :param machine: quantum machine
    :type machine: str
    :param shots: Number of shots
    :type shots: 
    :param parameters: algorithm parameters
    :type parameters: dict | bytes

    :rtype: None
    """


    
    parameterDict={}
    if connexion.request.is_json:
        parameters = Parameters.from_dict(connexion.request.get_json()).to_dict()  # noqa: E501
        for key in parameters.keys():
            globals()[key] = parameters[key]
            parameterDict[key] = parameters[key]
        
    gate_machines_arn= {"riggeti_aspen_m3":"arn:aws:braket:us-west-1::device/qpu/rigetti/Aspen-M-3", "DM1":"arn:aws:braket:::device/quantum-simulator/amazon/dm1", "oqc_lucy":"arn:aws:braket:eu-west-2::device/qpu/oqc/Lucy", "ionq_aria1":"arn:aws:braket:us-east-1::device/qpu/ionq/Aria-1", "ionq_aria2":"arn:aws:braket:us-east-1::device/qpu/ionq/Aria-2", "ionq_forte":"arn:aws:braket:us-east-1::device/qpu/ionq/Forte", "ionq_harmony":"arn:aws:braket:us-east-1::device/qpu/ionq/Harmony", "sv1":"arn:aws:braket:::device/quantum-simulator/amazon/sv1", "tn1":"arn:aws:braket:::device/quantum-simulator/amazon/tn1", "local":"local"}
    s3_folder = ("amazon-braket-7c2f2fa45286", "api")
    circuit = Circuit()
    circuit.h(0)
    circuit.h(1)
    circuit.h(2)
    circuit.x(0)
    circuit.x(2)
    circuit.x(3)
    circuit.h(3)
    circuit.rz(0, gamma)
    circuit.cnot(3, 0)
    circuit.cnot(3, 1)
    circuit.cnot(3, 2)
    circuit.x(0)
    circuit.x(2)
    circuit.h(0)
    circuit.h(1)
    circuit.h(2)
    
    return executeAWS(s3_folder, gate_machines_arn[machine], circuit, shots)




from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, transpile
from qiskit.providers.basic_provider import BasicProvider
from qiskit_ibm_provider import IBMProvider
from numpy import pi


def circuit_ib_mqiskit_parameterized(machine, shots, parameters=None):  # noqa: E501
    
    """Get the circuit implementation of circuit with parameters

     # noqa: E501

    :param machine: quantum machine
    :type machine: str
    :param shots: Number of shots
    :type shots: 
    :param parameters: algorithm parameters
    :type parameters: dict | bytes

    :rtype: None
    """


    
    parameterDict={}
    if connexion.request.is_json:
        parameters = Parameters.from_dict(connexion.request.get_json()).to_dict()  # noqa: E501
        for key in parameters.keys():
            globals()[key] = parameters[key]
            parameterDict[key] = parameters[key]
        
    qc = QuantumCircuit(4, 4)
    gate_machines_arn= {"local":"local", "ibm_brisbane":"ibm_brisbane", "ibm_osaka":"ibm_osaka", "ibm_kyoto":"ibm_kyoto", "simulator_stabilizer":"simulator_stabilizer", "simulator_mps":"simulator_mps", "simulator_extended_stabilizer":"simulator_extended_stabilizer", "simulator_statevector":"simulator_statevector"}
    
    
    qc.h(0)
    qc.h(1)
    qc.cx(0, 1)
    qc.rz(gamma, 1)
    qc.cx(0, 1)
    qc.h(2)
    qc.cx(0, 2)
    qc.rz(gamma, 2)
    qc.cx(0, 2)
    qc.rx(beta, 0)
    qc.cx(1, 2)
    qc.rz(gamma, 2)
    qc.cx(1, 2)
    qc.h(3)
    qc.cx(1, 3)
    qc.rz(gamma, 3)
    qc.cx(1, 3)
    qc.rx(beta, 1)
    qc.cx(2, 3)
    qc.rz(gamma, 3)
    qc.cx(2, 3)
    qc.rx(beta, 2)
    qc.rx(beta, 3)
    
    qc.barrier(range(4))
    qc.measure(range(4), range(4))
    
    
    if machine == "local":
        backend = BasicProvider().get_backend("basic_simulator")
        x = int(shots)
        transpiled_circuit = transpile(qc, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts
    else:
        provider = IBMProvider()
        backend = provider.get_backend(gate_machines_arn[machine])
        x = int(shots)
        transpiled_circuit = transpile(qc, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts




from braket.circuits import Gate
from braket.circuits import Circuit
from braket.devices import LocalSimulator
from braket.aws import AwsDevice


def deutsch_jozsa_aw_squirk(machine, shots):  # noqa: E501
    
    """Get the circuit implementation of Deutsch Jozsa Algorithm

     # noqa: E501

    :param machine: quantum machine
    :type machine: str
    :param shots: Number of shots
    :type shots: 

    :rtype: None
    """


    gate_machines_arn= {"riggeti_aspen_m3":"arn:aws:braket:us-west-1::device/qpu/rigetti/Aspen-M-3", "DM1":"arn:aws:braket:::device/quantum-simulator/amazon/dm1", "oqc_lucy":"arn:aws:braket:eu-west-2::device/qpu/oqc/Lucy", "ionq_aria1":"arn:aws:braket:us-east-1::device/qpu/ionq/Aria-1", "ionq_aria2":"arn:aws:braket:us-east-1::device/qpu/ionq/Aria-2", "ionq_forte":"arn:aws:braket:us-east-1::device/qpu/ionq/Forte", "ionq_harmony":"arn:aws:braket:us-east-1::device/qpu/ionq/Harmony", "sv1":"arn:aws:braket:::device/quantum-simulator/amazon/sv1", "tn1":"arn:aws:braket:::device/quantum-simulator/amazon/tn1", "local":"local"}
    s3_folder = ("amazon-braket-7c2f2fa45286", "api")
    circuit = Circuit()
    circuit.h(0)
    circuit.h(1)
    circuit.h(2)
    circuit.x(0)
    circuit.x(2)
    circuit.x(3)
    circuit.h(3)
    circuit.cnot(3, 0)
    circuit.cnot(3, 1)
    circuit.cnot(3, 2)
    circuit.x(0)
    circuit.x(2)
    circuit.h(0)
    circuit.h(1)
    circuit.h(2)
    return executeAWS(s3_folder, gate_machines_arn[machine], circuit, shots)




from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, transpile
from qiskit.providers.basic_provider import BasicProvider
from qiskit_ibm_provider import IBMProvider
from numpy import pi


def deutsch_jozsa_ib_mqiskit(machine, shots):  # noqa: E501
    
    """Get the circuit implementation of Deutsch Jozsa Algorithm

     # noqa: E501

    :param machine: quantum machine
    :type machine: str
    :param shots: Number of shots
    :type shots: 

    :rtype: None
    """


        
    qreg_q = QuantumRegister(4, 'q')
    creg_c = ClassicalRegister(2, 'c')
    circuit = QuantumCircuit(qreg_q, creg_c)
    gate_machines_arn= {"local":"local", "ibm_brisbane":"ibm_brisbane", "ibm_osaka":"ibm_osaka", "ibm_kyoto":"ibm_kyoto", "simulator_stabilizer":"simulator_stabilizer", "simulator_mps":"simulator_mps", "simulator_extended_stabilizer":"simulator_extended_stabilizer", "simulator_statevector":"simulator_statevector"}
    
    circuit.h(qreg_q[0])
    circuit.h(qreg_q[1])
    circuit.h(qreg_q[2])
    circuit.x(qreg_q[3])
    circuit.x(qreg_q[0])
    circuit.x(qreg_q[2])
    circuit.h(qreg_q[3])
    circuit.barrier(qreg_q[0], qreg_q[1], qreg_q[2], qreg_q[3])
    circuit.cx(qreg_q[0], qreg_q[3])
    circuit.cx(qreg_q[1], qreg_q[3])
    circuit.cx(qreg_q[2], qreg_q[3])
    circuit.barrier(qreg_q[0], qreg_q[1], qreg_q[2], qreg_q[3])
    circuit.x(qreg_q[0])
    circuit.h(qreg_q[1])
    circuit.x(qreg_q[2])
    circuit.h(qreg_q[0])
    circuit.h(qreg_q[2])
    circuit.barrier(qreg_q[0], qreg_q[1], qreg_q[2], qreg_q[3])
    circuit.measure(qreg_q[0], creg_c[0])
    circuit.measure(qreg_q[1], creg_c[1])
    circuit.measure(qreg_q[2], creg_c[1])
    
    if machine == "local":
        backend = BasicProvider().get_backend("basic_simulator")
        x = int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts
    else:
        provider = IBMProvider()
        backend = provider.get_backend(gate_machines_arn[machine])
        x = int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts




from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, transpile
from qiskit.providers.basic_provider import BasicProvider
from qiskit_ibm_provider import IBMProvider
from numpy import pi


def grover_ib_mqiskit(machine, shots):  # noqa: E501
    
    """Get the circuit implementation of Grover Algorithm

     # noqa: E501

    :param machine: quantum machine
    :type machine: str
    :param shots: Number of shots
    :type shots: 

    :rtype: None
    """


        
    q = QuantumRegister(2)
    c = ClassicalRegister(2)
    qc = QuantumCircuit(q, c)
    gate_machines_arn= {"local":"local", "ibm_brisbane":"ibm_brisbane", "ibm_osaka":"ibm_osaka", "ibm_kyoto":"ibm_kyoto", "simulator_stabilizer":"simulator_stabilizer", "simulator_mps":"simulator_mps", "simulator_extended_stabilizer":"simulator_extended_stabilizer", "simulator_statevector":"simulator_statevector"}
    
    qc.h(q[0])
    qc.h(q[1])
    qc.x(q[1])
    qc.h(q[1])
    qc.cx(q[0], q[1])
    qc.h(q[1])
    qc.x(q[1])
    qc.h(q[1])
    qc.measure(q, c)
    
    if machine == "local":
        backend = BasicProvider().get_backend("basic_simulator")
        x = int(shots)
        transpiled_circuit = transpile(qc, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts
    else:
        provider = IBMProvider()
        backend = provider.get_backend(gate_machines_arn[machine])
        x = int(shots)
        transpiled_circuit = transpile(qc, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts




from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, transpile
from numpy import pi
from qiskit.providers.basic_provider import BasicProvider
from qiskit_ibm_provider import IBMProvider
import qiskit.qasm3


def grover_ib_mquirk(machine, shots):  # noqa: E501
    
    """Get the circuit implementation of Grover Algorithm

     # noqa: E501

    :param machine: quantum machine
    :type machine: str
    :param shots: Number of shots
    :type shots: 

    :rtype: None
    """


    qreg_q = QuantumRegister(2, 'q')
    creg_c = ClassicalRegister(2, 'c')
    circuit = QuantumCircuit(qreg_q, creg_c)
    gate_machines_arn= {"local":"local", "ibm_brisbane":"ibm_brisbane", "ibm_osaka":"ibm_osaka", "ibm_kyoto":"ibm_kyoto", "simulator_stabilizer":"simulator_stabilizer", "simulator_mps":"simulator_mps", "simulator_extended_stabilizer":"simulator_extended_stabilizer", "simulator_statevector":"simulator_statevector"}
    circuit.h(qreg_q[0])
    circuit.h(qreg_q[1])
    circuit.x(qreg_q[1])
    circuit.h(qreg_q[1])
    circuit.cx(qreg_q[1], qreg_q[0])
    circuit.h(qreg_q[1])
    circuit.x(qreg_q[1])
    circuit.h(qreg_q[1])
    if machine == "local":
        backend = BasicProvider().get_backend("basic_simulator")
        x=int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts
    else:
        provider = IBMProvider()
        backend = provider.get_backend(gate_machines_arn[machine])
        x=int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, backend, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts




from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, transpile
from qiskit.providers.basic_provider import BasicProvider
from qiskit_ibm_provider import IBMProvider
from numpy import pi
import qiskit.qasm3


def maxcut3qubits_qasm(machine, shots):  # noqa: E501
    
    """Get the circuit implementation of max cut 3 qubits in QASM

     # noqa: E501

    :param machine: maxcut3qubitsQASM
    :type machine: str
    :param shots: Number of shots
    :type shots: 

    :rtype: None
    """


    gate_machines_arn = {"local":"local", "ibm_brisbane":"ibm_brisbane", "ibm_osaka":"ibm_osaka", "ibm_kyoto":"ibm_kyoto", "simulator_stabilizer":"simulator_stabilizer", "simulator_mps":"simulator_mps", "simulator_extended_stabilizer":"simulator_extended_stabilizer", "simulator_statevector":"simulator_statevector"}
    circuit = QuantumCircuit.from_qasm_str("OPENQASM 2.0;\ninclude \"qelib1.inc\";\nqreg q[3];\ncreg meas[3];\nh q[0];\nh q[1];\nrzz(1.0) q[0],q[1];\nh q[2];\nrzz(1.0) q[0],q[2];\nrx(2.0) q[0];\nrzz(1.0) q[1],q[2];\nrx(2.0) q[1];\nrx(2.0) q[2];\nbarrier q[0],q[1],q[2];\nmeasure q[0] -> meas[0];\nmeasure q[1] -> meas[1];\nmeasure q[2] -> meas[2];\n")
    if connexion.request.is_json:
        circuit.assign_parameters(parameterDict, inplace = True)
    if machine == "local":
        backend = BasicProvider().get_backend("basic_simulator")
        x = int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts
    else:
        provider = IBMProvider()
        backend = provider.get_backend(gate_machines_arn[machine])
        x = int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, backend, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts




from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, transpile
from qiskit.providers.basic_provider import BasicProvider
from qiskit_ibm_provider import IBMProvider
from numpy import pi
import qiskit.qasm3


def parameterized_qasm(machine, shots, parameters_qasm=None):  # noqa: E501
    
    """Get the circuit implementation of a parameterized circuit in QASM

     # noqa: E501

    :param machine: parameterizedQASM
    :type machine: str
    :param shots: Number of shots
    :type shots: 
    :param parameters_qasm: algorithm parameters
    :type parameters_qasm: dict | bytes

    :rtype: None
    """


    
    parameterDict={}
    if connexion.request.is_json:
        parameters_qasm = ParametersQASM.from_dict(connexion.request.get_json()).to_dict()  # noqa: E501
        for key in parameters_qasm.keys():
            globals()[key] = parameters_qasm[key]
            parameterDict[key] = parameters_qasm[key]
    gate_machines_arn = {"local":"local", "ibm_brisbane":"ibm_brisbane", "ibm_osaka":"ibm_osaka", "ibm_kyoto":"ibm_kyoto", "simulator_stabilizer":"simulator_stabilizer", "simulator_mps":"simulator_mps", "simulator_extended_stabilizer":"simulator_extended_stabilizer", "simulator_statevector":"simulator_statevector"}
    circuit = qiskit.qasm3.loads("OPENQASM 3;\ninclude \"stdgates.inc\";\ninput float[64] beta0;\ninput float[64] gamma0;\ngate rzz_1466526231824(gamma0) _gate_q_0, _gate_q_1 {\n  cx _gate_q_0, _gate_q_1;\n  rz(gamma0) _gate_q_1;\n  cx _gate_q_0, _gate_q_1;\n}\ngate rzz_1466525103632(gamma0) _gate_q_0, _gate_q_1 {\n  cx _gate_q_0, _gate_q_1;\n  rz(gamma0) _gate_q_1;\n  cx _gate_q_0, _gate_q_1;\n}\ngate rzz_1466532946384(gamma0) _gate_q_0, _gate_q_1 {\n  cx _gate_q_0, _gate_q_1;\n  rz(gamma0) _gate_q_1;\n  cx _gate_q_0, _gate_q_1;\n}\ngate rzz_1466526338000(gamma0) _gate_q_0, _gate_q_1 {\n  cx _gate_q_0, _gate_q_1;\n  rz(gamma0) _gate_q_1;\n  cx _gate_q_0, _gate_q_1;\n}\ngate rzz_1466526335120(gamma0) _gate_q_0, _gate_q_1 {\n  cx _gate_q_0, _gate_q_1;\n  rz(gamma0) _gate_q_1;\n  cx _gate_q_0, _gate_q_1;\n}\nbit[4] meas;\nqubit[4] q;\nh q[0];\nh q[1];\nrzz_1466526231824(gamma0) q[0], q[1];\nh q[2];\nrzz_1466525103632(gamma0) q[0], q[2];\nrx(2.0*beta0) q[0];\nrzz_1466532946384(gamma0) q[1], q[2];\nh q[3];\nrzz_1466526338000(gamma0) q[1], q[3];\nrx(2.0*beta0) q[1];\nrzz_1466526335120(gamma0) q[2], q[3];\nrx(2.0*beta0) q[2];\nrx(2.0*beta0) q[3];\nbarrier q[0], q[1], q[2], q[3];\nmeas[0] = measure q[0];\nmeas[1] = measure q[1];\nmeas[2] = measure q[2];\nmeas[3] = measure q[3];\n")
    if connexion.request.is_json:
        circuit.assign_parameters(parameterDict, inplace = True)
    if machine == "local":
        backend = BasicProvider().get_backend("basic_simulator")
        x = int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts
    else:
        provider = IBMProvider()
        backend = provider.get_backend(gate_machines_arn[machine])
        x = int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, backend, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts




from braket.circuits import Gate
from braket.circuits import Circuit
from braket.devices import LocalSimulator
from braket.aws import AwsDevice


def shor_aw_squirk(machine, shots):  # noqa: E501
    
    """Get the circuit implementation of Shor Algorithm

     # noqa: E501

    :param machine: Shor&#39;s algorithm is a quantum computer algorithm for finding the prime factors of an integer
    :type machine: str
    :param shots: Number of shots
    :type shots: 

    :rtype: None
    """


    gate_machines_arn= {"riggeti_aspen_m3":"arn:aws:braket:us-west-1::device/qpu/rigetti/Aspen-M-3", "DM1":"arn:aws:braket:::device/quantum-simulator/amazon/dm1", "oqc_lucy":"arn:aws:braket:eu-west-2::device/qpu/oqc/Lucy", "ionq_aria1":"arn:aws:braket:us-east-1::device/qpu/ionq/Aria-1", "ionq_aria2":"arn:aws:braket:us-east-1::device/qpu/ionq/Aria-2", "ionq_forte":"arn:aws:braket:us-east-1::device/qpu/ionq/Forte", "ionq_harmony":"arn:aws:braket:us-east-1::device/qpu/ionq/Harmony", "sv1":"arn:aws:braket:::device/quantum-simulator/amazon/sv1", "tn1":"arn:aws:braket:::device/quantum-simulator/amazon/tn1", "local":"local"}
    s3_folder = ("amazon-braket-7c2f2fa45286", "api")
    circuit = Circuit()
    circuit.h(0)
    circuit.h(1)
    circuit.h(2)
    circuit.h(3)
    circuit.x(0)
    circuit.x(0)
    circuit.x(1)
    circuit.x(2)
    circuit.x(3)
    circuit.cnot(2, 1)
    circuit.cnot(1, 2)
    circuit.cnot(2, 1)
    circuit.cnot(3, 2)
    circuit.cnot(2, 3)
    circuit.cnot(3, 2)
    circuit.cnot(3, 0)
    circuit.cnot(0, 3)
    circuit.cnot(3, 0)
    return executeAWS(s3_folder, gate_machines_arn[machine], circuit, shots)




from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, transpile
from qiskit.providers.basic_provider import BasicProvider
from qiskit_ibm_provider import IBMProvider
from numpy import pi


def shor_ib_mqiskit(machine, shots):  # noqa: E501
    
    """Get the circuit implementation of Shor Algorithm

     # noqa: E501

    :param machine: quantum machine
    :type machine: str
    :param shots: Number of shots
    :type shots: 

    :rtype: None
    """


        
    qreg_q = QuantumRegister(4, 'q')
    creg_c = ClassicalRegister(4, 'c')
    circuit = QuantumCircuit(qreg_q, creg_c)
    gate_machines_arn= {"local":"local", "ibm_brisbane":"ibm_brisbane", "ibm_osaka":"ibm_osaka", "ibm_kyoto":"ibm_kyoto", "simulator_stabilizer":"simulator_stabilizer", "simulator_mps":"simulator_mps", "simulator_extended_stabilizer":"simulator_extended_stabilizer", "simulator_statevector":"simulator_statevector"}
    
    circuit.reset(qreg_q[0])
    circuit.reset(qreg_q[1])
    circuit.reset(qreg_q[2])
    circuit.reset(qreg_q[3])
    circuit.x(qreg_q[0])
    circuit.x(qreg_q[0])
    circuit.x(qreg_q[1])
    circuit.x(qreg_q[2])
    circuit.x(qreg_q[3])
    circuit.cx(qreg_q[1], qreg_q[2])
    circuit.cx(qreg_q[2], qreg_q[1])
    circuit.cx(qreg_q[1], qreg_q[2])
    circuit.cx(qreg_q[2], qreg_q[3])
    circuit.cx(qreg_q[3], qreg_q[2])
    circuit.cx(qreg_q[2], qreg_q[3])
    circuit.cx(qreg_q[0], qreg_q[3])
    circuit.cx(qreg_q[3], qreg_q[0])
    circuit.cx(qreg_q[0], qreg_q[3])
    circuit.measure(qreg_q[0], creg_c[0])
    circuit.measure(qreg_q[1], creg_c[1])
    circuit.measure(qreg_q[2], creg_c[2])
    circuit.measure(qreg_q[3], creg_c[3])
    
    if machine == "local":
        backend = BasicProvider().get_backend("basic_simulator")
        x = int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts
    else:
        provider = IBMProvider()
        backend = provider.get_backend(gate_machines_arn[machine])
        x = int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts




from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, transpile
from qiskit.providers.basic_provider import BasicProvider
from qiskit_ibm_provider import IBMProvider
from numpy import pi


def simon_ib_mqiskit(machine, shots):  # noqa: E501
    
    """Get the circuit implementation of Simon Algorithm

     # noqa: E501

    :param machine: quantum machine
    :type machine: str
    :param shots: Number of shots
    :type shots: 

    :rtype: None
    """


        
    qreg_q = QuantumRegister(6, 'q')
    creg_c = ClassicalRegister(4, 'c')
    circuit = QuantumCircuit(qreg_q, creg_c)
    gate_machines_arn= {"local":"local", "ibm_brisbane":"ibm_brisbane", "ibm_osaka":"ibm_osaka", "ibm_kyoto":"ibm_kyoto", "simulator_stabilizer":"simulator_stabilizer", "simulator_mps":"simulator_mps", "simulator_extended_stabilizer":"simulator_extended_stabilizer", "simulator_statevector":"simulator_statevector"}
    
    circuit.h(qreg_q[0])
    circuit.h(qreg_q[1])
    circuit.h(qreg_q[2])
    circuit.barrier(qreg_q[0], qreg_q[1], qreg_q[2], qreg_q[3], qreg_q[4], qreg_q[5])
    circuit.cx(qreg_q[0], qreg_q[3])
    circuit.cx(qreg_q[1], qreg_q[4])
    circuit.cx(qreg_q[2], qreg_q[5])
    circuit.cx(qreg_q[1], qreg_q[4])
    circuit.cx(qreg_q[1], qreg_q[5])
    circuit.barrier(qreg_q[0], qreg_q[1], qreg_q[2], qreg_q[3], qreg_q[4], qreg_q[5])
    circuit.h(qreg_q[0])
    circuit.h(qreg_q[1])
    circuit.h(qreg_q[2])
    circuit.measure(qreg_q[0], creg_c[0])
    circuit.measure(qreg_q[1], creg_c[1])
    circuit.measure(qreg_q[2], creg_c[2])
    
    if machine == "local":
        backend = BasicProvider().get_backend("basic_simulator")
        x = int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts
    else:
        provider = IBMProvider()
        backend = provider.get_backend(gate_machines_arn[machine])
        x = int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts




from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, transpile
from numpy import pi
from qiskit.providers.basic_provider import BasicProvider
from qiskit_ibm_provider import IBMProvider
import qiskit.qasm3


def simon_ib_mquirk(machine, shots):  # noqa: E501
    
    """Get the circuit implementation of Simon Algorithm

     # noqa: E501

    :param machine: quantum machine
    :type machine: str
    :param shots: Number of shots
    :type shots: 

    :rtype: None
    """


    qreg_q = QuantumRegister(6, 'q')
    creg_c = ClassicalRegister(6, 'c')
    circuit = QuantumCircuit(qreg_q, creg_c)
    gate_machines_arn= {"local":"local", "ibm_brisbane":"ibm_brisbane", "ibm_osaka":"ibm_osaka", "ibm_kyoto":"ibm_kyoto", "simulator_stabilizer":"simulator_stabilizer", "simulator_mps":"simulator_mps", "simulator_extended_stabilizer":"simulator_extended_stabilizer", "simulator_statevector":"simulator_statevector"}
    circuit.h(qreg_q[0])
    circuit.h(qreg_q[1])
    circuit.h(qreg_q[2])
    circuit.cx(qreg_q[3], qreg_q[0])
    circuit.cx(qreg_q[4], qreg_q[1])
    circuit.cx(qreg_q[5], qreg_q[2])
    circuit.cx(qreg_q[4], qreg_q[1])
    circuit.cx(qreg_q[5], qreg_q[1])
    circuit.h(qreg_q[0])
    circuit.h(qreg_q[1])
    circuit.h(qreg_q[2])
    circuit.measure(qreg_q[0], creg_c[0])
    circuit.measure(qreg_q[1], creg_c[1])
    circuit.measure(qreg_q[2], creg_c[2])
    if machine == "local":
        backend = BasicProvider().get_backend("basic_simulator")
        x=int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts
    else:
        provider = IBMProvider()
        backend = provider.get_backend(gate_machines_arn[machine])
        x=int(shots)
        transpiled_circuit = transpile(circuit, backend)
        job = backend.run(transpiled_circuit, backend, shots=x)
        result = job.result()
        counts = result.get_counts()
        return counts


